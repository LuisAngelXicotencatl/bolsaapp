
<?php $__env->startSection('title', 'Nuevo Evento'); ?>
<?php $__env->startSection("content"); ?>
    <main>
        <div class="update-content">
            <!--<div class="update-title">Eventos</div>-->
            <div class="update-title">Agregar empresa</div>
        </div>
        <div class="update-content">
            <form action="<?php echo e(route('Empresa.agregarProcess')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <!--Titulo-->
                <div class="update-event-content">
                    <Label class="update-event-label">Nombre</Label>
                    <input class="update-event-title"  name="nombre" value="<?php echo e(old('nombre')); ?>">
                </div>
                <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span>*<?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <!--subtitulo-->
                <div class="update-event-content">
                    <Label class="update-event-label">Descripcion</Label>
                    <input class="update-event-bubtitle" name="descripcion" value="<?php echo e(old('descripcion')); ?>">
                </div>
                <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <br>
                    <span>*<?php echo e($message); ?></span>
                    <br>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <button class="tarjet-event-button-deleteupdate" type="submit">Agregar</button>
            </form>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bolsa-app\resources\views/empresas/new.blade.php ENDPATH**/ ?>