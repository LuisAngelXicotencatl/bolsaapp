
<?php $__env->startSection('title',); ?>
<?php $__env->startSection("content"); ?>
<main>
    <div class="event-i">
        <div class="event-i-title"><?php echo e($empresa->Nombre); ?></div>
        <div class="event-i-sub"><?php echo e($empresa->Descripcion); ?></div>
        <div class="event-i-details">
            <div class="event-i-info">
                <li>
                    <ul>Correo: <?php echo e($empresa->email); ?></ul>
                    <ul>Pass: <?php echo e($empresa->Contrasena); ?></ul>
                </li>
            </div>
        </div>
        <form action="<?php echo e(route('destroyempresa', $empresa->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button class="tarjet-event-button-delete" type="submit">Eliminar empresa</button>
        </form>
        <!--<a href="<?php echo e(route('destroyempresa', $empresa->id)); ?>"><button class="tarjet-event-button-delete" type="submit">Eliminar empresa</button></a>-->
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bolsa-app\resources\views/empresas/show.blade.php ENDPATH**/ ?>