

<?php $__env->startSection('title', $event->titulo); ?>

<?php $__env->startSection("content"); ?>
<main>
    <div class="event-i">
        <div class="event-i-title"><?php echo e($event->titulo); ?></div>
        <div class="event-i-sub"><?php echo e($event->subtitulo); ?></div>
        <p class="event-i-descripcion"><?php echo e($event->descripcion); ?></p>
        <li>
            <ul>Fecha: <?php echo e($event->fecha); ?></ul>
            <ul>Lugar: <?php echo e($event->lugar); ?></ul>
        </li>
        <div class="event-i-details">
            <div class="event-i-info">
                <form action="<?php echo e(route('Event.newdateProcess', $event->id)); ?>" method="post">
                    <div class="eventos-title">Agregar fecha</div>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <!--Titulo-->
                    <input type="hidden" value="<?php echo e($event->id); ?>" name="id_event">
                    <div class="update-event-content">
                        <Label class="update-event-label">Fecha</Label>
                        <input class="update-event-title"  name="fecha" type="date">
                        <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span>*<?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <!--subtitulo-->
                    <div class="update-event-content">
                        <Label class="update-event-label">Hora</Label>
                        <input class="update-event-bubtitle" name="hora" type="time">
                    <?php $__errorArgs = ['hora'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span>*<?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button class="tarjet-event-button-deleteupdate" type="submit">Agregar fecha</button>
                </form>
            </div>
        </div>           
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bolsa-app\resources\views/events/newdate.blade.php ENDPATH**/ ?>