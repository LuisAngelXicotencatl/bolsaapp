
<?php $__env->startSection('title', $event->titulo); ?>
<?php $__env->startSection("content"); ?>
<main>
    <div class="event-i">
        <div class="event-i-title"><?php echo e($event->titulo); ?></div>
        <div class="event-i-sub"><?php echo e($event->subtitulo); ?></div>
        <p class="event-i-descripcion"><?php echo e($event->descripcion); ?>, <?php echo e($event->id); ?></p>
        <div class="event-i-details">
            <div class="event-i-info">
                <ul>
                    <li>Fecha: <?php echo e($event->fecha); ?></li>
                    <li>Lugar: <?php echo e($event->lugar); ?></li>
                </ul>
            </div>
        </div>

        <?php if($eventEmpresa): ?>
            <div class="eventos-title">Cita ya programada</div>
            <div class="event-i-details">
                <div class="event-i-sub">Ya tienes una cita programada para este evento.</div>
                <?php if($eventEmpresa): ?>
                    <a href="<?php echo e(route('vercita', $eventEmpresa->id)); ?>"><button class="tarjet-event-button-c" type="button">Ver cita</button></a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="eventos-title">Fechas disponibles <?php echo e(session('empresa_id')); ?></div>
            <?php if($eventDates->count() > 0): ?>
                <section class="soon">
                    <?php $__currentLoopData = $eventDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventDate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="soon-event">
                            <?php if($eventDate->date): ?>
                                <div class="soon-event-date">
                                    <div class="soon-event-info-label"><?php echo e($eventDate->date->fecha); ?></div>
                                    <div class="soon-event-info-label"><?php echo e($eventDate->date->hora); ?></div>
                                    <div class="soon-event-info-label"><?php echo e($eventDate->date->id); ?></div>
                                </div>
                                <div class="soon-event-info">
                                    <div class="tarjet-event-buttons">
                                        <form action="<?php echo e(route('agendarcita', $eventDate->date->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="idempresa" value="<?php echo e(session('empresa_id')); ?>">
                                            <input type="hidden" name="idevent" value="<?php echo e($event->id); ?>">
                                            <input type="hidden" name="nameempresa" value="<?php echo e(session('empresa_name')); ?>">
                                            <button class="tarjet-event-button-c" type="submit">Tomar cita</button>
                                        </form>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </section>
            <?php else: ?>
                <div class="event-i-details">
                    <div class="soon-event-date">
                        <div class="event-i-sub">No existen horarios disponibles...</div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <div class="eventos-title">Fechas tomadas</div>
        <?php if($eventDatestake->count() > 0): ?>
            <section class="soon">
                <?php $__currentLoopData = $eventDatestake; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $takenDate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="soon-event">
                        <?php if($takenDate->date): ?>
                            <div class="soon-event-date">
                                <div class="soon-event-info-label"><?php echo e($takenDate->date->fecha); ?></div>
                                <div class="soon-event-info-label"><?php echo e($takenDate->date->hora); ?></div>
                            </div>
                            <div class="event-i-sub-c">No disponible</div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        <?php else: ?>
            <div class="event-i-details">
                <div class="event-i-sub">No hay citas tomadas</div>
            </div>
        <?php endif; ?>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cliente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bolsa-app\resources\views/clientes/evento.blade.php ENDPATH**/ ?>