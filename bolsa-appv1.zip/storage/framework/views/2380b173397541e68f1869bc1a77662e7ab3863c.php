
<?php $__env->startSection('title', $event->titulo); ?>
<?php $__env->startSection("content"); ?>
    <main>
        <div class="update-content">
            <div class="update-title"><?php echo e($event->titulo); ?></div>
            <div class="update-title">Evento con el Id- <?php echo e($event->id); ?> y  con la fecha de <?php echo e($event->fecha); ?></div>
            <form action="<?php echo e(route('event.destroy', $event->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button class="tarjet-event-button-deletenew" type="submit">Eliminar evento futuro</button>
            </form>
        </div>
        <div class="update-content">
            <form action="<?php echo e(route('Event.updatefinished', $event->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <button class="tarjet-event-button" type="submit">Marcar evento como terminado</button>
            </form>
        </div>
        <div class="update-content">
            <form action="<?php echo e(route('Event.updateProcess', $event->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <!--Titulo-->
                <div class="update-event-content">
                    <Label class="update-event-label">Titulo</Label>
                    <input class="update-event-title"  name="titulo" value="<?php echo e(old('titulo',$event->titulo)); ?>">
                </div>
                <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span>*<?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <!--subtitulo-->
                <div class="update-event-content">
                    <Label class="update-event-label">Subitulo</Label>
                    <input class="update-event-bubtitle" name="subtitulo" value="<?php echo e(old('subtitulo',$event->subtitulo)); ?>">
                </div>
                <?php $__errorArgs = ['subtitulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <br>
                    <span>*<?php echo e($message); ?></span>
                    <br>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <!--descripcion-->
                <div class="update-event-content">
                    <label class="update-event-label">Descripcion</label>
                    <textarea  name="descripcion" rows="2"><?php echo e(old('avatar', $event->descripcion)); ?></textarea>
                </div>
                <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span>*<?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <!--detalles-->
                <div class="event-i-details">
                    <div class="update-event-info event-i-academias">
                        <li>
                            <ul>Fecha: <input name="fecha" value="<?php echo e(old('avatar', $event->fecha)); ?>"></ul>
                            <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span>*<?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <ul>Lugar: <input  name="lugar" value="<?php echo e(old('avatar', $event->lugar)); ?>"></ul>
                            <?php $__errorArgs = ['lugar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span>*<?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </li>
                    </div>
                </div>
                <button class="tarjet-event-button-deleteupdate" type="submit">Actualizar infomacion</button>
            </form>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bolsa-app\resources\views/events/soonUpdate.blade.php ENDPATH**/ ?>