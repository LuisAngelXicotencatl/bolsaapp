

<?php $__env->startSection('title', $event->titulo); ?>

<?php $__env->startSection("content"); ?>
<main>
    <div class="event-i">
        <div class="event-i-title"><?php echo e($event->titulo); ?></div>
        <div class="event-i-sub"><?php echo e($event->subtitulo); ?></div>
        <p class="event-i-descripcion"><?php echo e($event->descripcion); ?></p>
        <div class="event-i-details">
            <div class="event-i-info">
                <li>
                    <ul>Fecha: <?php echo e($event->fecha); ?></ul>
                    <ul>Lugar: <?php echo e($event->lugar); ?></ul>
                </li>
            </div>
        </div>
        <div>
            <a class="buttonexcel" href="<?php echo e(route('date.new', $event->id)); ?>"><button class="tarjet-event-button-delete" type="submit">Nuevo horario</button></a>
            <a class="buttonexcel" href="<?php echo e(route('event.export', $event->id)); ?>"><button class="tarjet-event-button">Descargar Excel</button></a>
        </div>
    </div>
    <div class="eventos-title">Fechas disponibles</div>
    <?php if($eventDates->count() > 0): ?>
    <section class="soon">
        <?php $__currentLoopData = $eventDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventDate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="soon-event">
                <div class="soon-event-date">
                    <div class="soon-event-info-label"><?php echo e($eventDate->date->fecha); ?></div>
                    <div class="soon-event-info-label"><?php echo e($eventDate->date->hora); ?></div>
                </div>
                <div class="soon-event-info">
                    <div class="soon-event-info-label"></div>
                    <div class="tarjet-event-buttons">
                        <form action="<?php echo e(route('event.destroyDate', $eventDate->date->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button class="tarjet-event-button-deletenew" type="submit">Eliminar</button>
                        </form>
                        <a href="<?php echo e(route('event.updateDate', $eventDate->date->id)); ?>"><button class="tarjet-event-button">Modificar</button></a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
    <?php else: ?>
    <div class="event-i-details">
        <div class="soon-event-date">
            <div class="event-i-sub">No existen horarios disponibles...</div>
        </div>
    </div>
    <?php endif; ?>
    </div>
    <div class="eventos-title">Fechas tomadas</div>
    <?php if($eventDatestake->count() > 0): ?>
        <section class="soon">
            <?php $__currentLoopData = $eventDatestake; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventDatestake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="soon-event">
                    <div class="soon-event-date">
                        <div class="soon-event-info-label"><?php echo e($eventDatestake->date->fecha); ?></div>
                        <div class="soon-event-info-label"><?php echo e($eventDatestake->date->hora); ?></div>
                    </div>
                    <div class="soon-event-info">
                        <div class="soon-event-info-label"><?php echo e($eventDatestake->date->empresa); ?></div>
                        <div class="tarjet-event-buttons">
                            <form action="<?php echo e(route('event.destroyDate', $eventDatestake->date->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button class="tarjet-event-button-deletenew" type="submit">Eliminar</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
    <?php else: ?>
    <div class="event-i-details">
        <div class="event-i-sub">Nadie ha tomado alguna cita..</div>
    </div>
    <?php endif; ?>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bolsa-app\resources\views/events/dates.blade.php ENDPATH**/ ?>