
<?php $__env->startSection('title', $event->titulo); ?>
<?php $__env->startSection("content"); ?>
<main>
    <div class="event-i">
        <div class="event-i-title"><?php echo e($event->titulo); ?></div>
        <div class="event-i-sub"><?php echo e($event->subtitulo); ?></div>
        <p class="event-i-descripcion"><?php echo e($event->descripcion); ?></p>
        <div class="event-i-details">
            <div class="event-i-info">
                <li>
                    <ul>Fecha: <?php echo e($event->fecha); ?></ul>
                    <ul>Lugar: <?php echo e($event->lugar); ?></ul>
                </li>
            </div>
        </div>
    </div>

    <div class="eventos-title">Mi cita</div>
    <?php if($date): ?>
    <div class="event-i-details">
        <div class="event-i-sub">Fecha: <?php echo e($date->fecha); ?></div>
        <div class="event-i-sub">Hora: <?php echo e($date->hora); ?></div>
        <form action="<?php echo e(route('destroymicita', $eventEmpresa->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button class="tarjet-event-button-c" type="submit">Eliminar mi cita</button>
        </form>
    </div>
    <?php else: ?>
        <div class="event-i-details">
            <div class="event-i-sub">No se ha encontrado la fecha de la cita.</div>
        </div>
    <?php endif; ?>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cliente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bolsa-app\resources\views/clientes/vercita.blade.php ENDPATH**/ ?>