
<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection("content"); ?>
        <main>
            <section class="login">
                <img class="login-logo" src="<?php echo e(asset('images/logoFcc.png')); ?>" alt="Logo">
                <form class="loginform" action="<?php echo e(route('inicio.login')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <label for="email">Correo</label>
                    <input id="email" name="email" type="text" required class="login-input">
                    <label for="password">Contraseña</label>
                    <input id="password" name="password" type="password" required class="login-input">
                    <button type="submit" class="login-button">Iniciar sesión</button>
                </form>
            </section>
        </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bolsa-app\resources\views/home/login.blade.php ENDPATH**/ ?>