
<?php $__env->startSection('title', $event->titulo); ?>
<?php $__env->startSection("content"); ?>
<main>
    <div class="event-i">
        <div class="event-i-title"><?php echo e($event->titulo); ?></div>
        <div class="event-i-sub"><?php echo e($event->subtitulo); ?></div>
        <p class="event-i-descripcion"><?php echo e($event->descripcion); ?></p>
        <div class="event-i-details">
            <div class="event-i-info">
                <li>
                    <ul>Fecha: <?php echo e($event->fecha); ?></ul>
                    <ul>Lugar: <?php echo e($event->lugar); ?></ul>
                    <ul>Premio: <?php echo e($event->premio); ?></ul>
                    </li>
                </div>
                <div class="event-i-academias">
                    <li>Empresas y Academias
                        <ul>No disponible</ul>
                        <!--<?php $__currentLoopData = $eventEmpresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventEmpresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul>  <?php echo e($eventEmpresa->empresa->Nombre); ?></ul>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
                    </li>
                </div>
            </div>
        </div>
        <div class="event-i-images">
            <?php $__currentLoopData = $event->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="images-i-z">
                    <?php
                        $imagePath = 'storage/' . str_replace('\\', '/', $image->image);
                    ?>
                    <img class="tarjet-event-image" src="<?php echo e(asset($imagePath)); ?>">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cliente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bolsa-app\resources\views/clientes/show.blade.php ENDPATH**/ ?>