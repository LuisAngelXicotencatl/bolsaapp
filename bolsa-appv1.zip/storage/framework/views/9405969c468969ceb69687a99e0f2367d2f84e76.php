
<?php $__env->startSection('title', 'Cursos edit'); ?>
<?php $__env->startSection("content"); ?>
<h1>En esta pagina podras editar un curso</h1>
<?php echo e(route('cursos.store')); ?>

<form action="<?php echo e(route('cursos.update', $id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <label>
        Nombre
        <input type="text", name="name" value="<?php echo e(old('name',$id->name)); ?>">
    </label>
    <br>
    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <span>*<?php echo e($message); ?></span>
        <br>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <label>
        Descripcion
        <input type="text", name="descripcion" value="<?php echo e(old('descripcion',$id->descripcion)); ?>">
    </label>
    <br>
    <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <span>*<?php echo e($message); ?></span>
        <br>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <label>
        Avatar
        <input type="text", name="avatar" value="<?php echo e(old('avatar', $id->avatar)); ?>">
    </label> 
    <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <span>*<?php echo e($message); ?></span>
        <br>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <button type="submit">Actualizar formulario</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bolsa-app\resources\views/cursos/edit.blade.php ENDPATH**/ ?>