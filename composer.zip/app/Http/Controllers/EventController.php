<?php

namespace App\Http\Controllers;

use App\Models\Event;
use Illuminate\Http\Request;

class EventController extends Controller
{
    public function index(){
        $events =  Event::with('images')->where('status', 1)->orderBy('id', 'desc')->get();
        $soons =  Event::where('status', 0)->orderBy('id', 'desc')->get();
        return view('events.index', compact('events', 'soons'));
    }

    public function show($id){
        /*return "Bienvenido $curso";*/
        $event = Event::find($id);
        /*return $event;*/
        return view('events.show', compact('event'));
    }
}

