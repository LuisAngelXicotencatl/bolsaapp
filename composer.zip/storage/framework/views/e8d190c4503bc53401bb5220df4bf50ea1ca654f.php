
<?php $__env->startSection('title', 'Cursos'); ?>
<?php $__env->startSection("content"); ?>
<main>
    <div class="welcome">Bienvenido de regreso, Luis Angelsss.
    </div>
    <div class="eventos-title">Proximos eventos</div>
    <section class="soon">
        <?php $__currentLoopData = $soons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="soon-event">
            <div class="soon-event-date">
                <div class="soon-event-info-label"><?php echo e($soon->fecha); ?></div>
            </div>
            <div class="soon-event-info">
                <div class="soon-event-info-label"><?php echo e($soon->titulo); ?></div>
                <div class="tarjet-event-buttons">
                    <a href="fechas.html"><button class="tarjet-event-button-delete">Fechas</button></a>
                    <a href="newEvent.html"><button class="tarjet-event-button">Modificar</button></a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
    <div class="eventos-title">Eventos pasados</div>

    <section class="eventos">
    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="tarjet-event" id="1">
            <div class="tarjet-event-name"><?php echo e($event->titulo); ?></div>
            <div class="tarjet-event-info"><?php echo e($event->subtitulo); ?> </div>
            <?php $__currentLoopData = $event->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img class="tarjet-event-image" src="<?php echo e($image->image); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($event->firstImage): ?>
                <img class="tarjet-event-image" src="<?php echo e($event->firstImage->image); ?>">
            <?php endif; ?>
            <div class="tarjet-event-buttons">
                <a><button class="tarjet-event-button-delete" id="delete">Eliminar</button></a>
                <a href="<?php echo e(route('Event.show', $event->id)); ?>"><button class="tarjet-event-button">Modificar</button></a>
            </div>
            <script src="js/Quiz.js"></script>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
    <div class="tarjet-event-more">
        <button class="tarjet-event-button" id="verMasBtn">Ver más</button>
        <button class="tarjet-event-button" id="verMenosBtn">Ver menos</button>
    </div>
    <script src="js/bucle.js"></script>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bolsa-app\resources\views/events/index.blade.php ENDPATH**/ ?>