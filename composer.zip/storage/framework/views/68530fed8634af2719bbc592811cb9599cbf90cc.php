
<?php $__env->startSection('title', 'Curso ' . $curso->name); ?>
<?php $__env->startSection("content"); ?>
    <!-- <h1>Bienvenido //<// ?php echo $curso;?> </h1> -->
    <h1>Bienvenido al curso de <?php echo e($curso ->name); ?> </h1>
    <a href="<?php echo e(route('cursps.index')); ?>">Volver a curso</a>
    <br>
    <a href="<?php echo e(route('cursos.edit', $curso)); ?>">Editar curso</a>
    <p>Avatar:  <?php echo e($curso ->avatar); ?></p>
    <p>Categoria:  <?php echo e($curso ->descripcion); ?></p>
    <form action="<?php echo e(route('curso.destroy', $curso)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <button type="submit">Eliminar</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bolsa-app\resources\views/cursos/show.blade.php ENDPATH**/ ?>