
<?php $__env->startSection('title', $event->titulo); ?>
<?php $__env->startSection("content"); ?>
<main>
    <div class="event-i">
        <div class="event-i-title"><?php echo e($event->titulo); ?></div>
        <div class="event-i-sub"><?php echo e($event->subtitulo); ?></div>
        <p class="event-i-descripcion"><?php echo e($event->descripcion); ?></p>
        <div class="event-i-details">
            <div class="event-i-info">
                <li>
                    <ul>Fecha: <?php echo e($event->fecha); ?></ul>
                    <ul>Lugar: <?php echo e($event->lugar); ?></ul>
                    <ul>Premio: <?php echo e($event->premio); ?></ul>
                    </li>
                </div>
                <div class="event-i-academias">
                    <li>Empresas y Academias
                        <ul>Oracle</ul>
                        <ul>VW</ul>
                        <ul>T-SYSTEM</ul>
                    </li>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bolsa-app\resources\views/events/show.blade.php ENDPATH**/ ?>