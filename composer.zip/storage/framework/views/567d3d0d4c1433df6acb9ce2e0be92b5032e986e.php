<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/nav.css">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>">
    <title>Bolsa de trabajo</title>
</head>
<!--<section>
    <div>Cordinadora</div>
    <div>Eventos</div>
    <div>Academias</div>
    <div>Recursos</div>
</section>-->
<body>
    <header>
        <nav class="nav">
            <img class="imagelogo" src="images/logoFcc.png">
            <section class="menu">
                <a href="#nosotros" class="label">Nosotros</a>
                <a href="#eventos" class="label">Eventos</a>
                <a href="#cordinador" class="label">Cordinadora</a>
            </section>
            <a href="#empresas" id="vinculacion" class="label">Vinculacion</a>
            <img class="imagelogo" id="imagelogo"src="images/vinculacionFcc.png">

            <button class="menu-toggle" aria-label="Toggle Menu">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                  <path d="M0 0h24v24H0z" fill="none"/>
                  <path d="M4 6h16v2H4zm0 5h16v2H4zm0 5h16v2H4z"/>
                </svg>
            </button>
        </nav>
    </header>
    <main class="section-w" id="nosotros">
        <!--Nosotros-->
        <div class="nosotros">
            <div class="nostros-content">
                <div class="nostros-content-title">Bolsa de trabajo FCC</div>
                <div class="nostros-content-text">La Bolsa de Trabajo de la Facultad de Ciencias de la Computación tiene el compromiso de ser un centro de información y consulta que vincule a nuestros alumnos y egresados con las necesidades profesionales de las empresas y organizaciones, brindando una alternativa viable y sustentable que cubra el perfil que solicitan.</div>
            </div>
            <div class="nostros-images">
                <div class="nostros-images-col-a">
                    <img src="<?php echo e(asset('images/empresas/audi.png')); ?>" alt="" class="nostros-images-col-a-image">
                    <img src="<?php echo e(asset('images/empresas/Oracle_Logo.jpg')); ?>" alt="" class="nostros-images-col-a-image">
                </div>
                <div class="nostros-images-col-b">
                    <img src="<?php echo e(asset('images/empresas/tsystemsmexico.png')); ?>" alt="" class="nostros-images-col-b-image">
                    <img src="<?php echo e(asset('iimages/empresas/buap.png')); ?>" alt="" class="nostros-images-col-b-image">
                </div>
                <div class="nostros-images-col-c">
                    <img src="<?php echo e(asset('images/empresas/vw.png')); ?>" alt="" class="image">
                    <img src="<?php echo e(asset('images/empresas/meta2.png')); ?>" alt="" class="image">
                    <img src="images/empresas/Oracle_Logo.jpg <?php echo e(asset('images/empresas/Oracle_Logo.jpg')); ?>" alt="" class="image">
                </div>
            </div>
        </div>
        <!--EVENTOS-->
        <div class="eventos-title">Eventos pasados</div>
        <section class="eventos" id="eventos">
            <div class="tarjet-event" id="2">
                <div class="tarjet-event-name">Hackathon ETH</div>
                <div class="tarjet-event-info">2do Lugar en el Hackathon ETH </div>
                <img class="tarjet-event-image" src="images/ejm1.jpg">
                <div class="tarjet-event-buttons">
                    <a class="tarjet-event-link">15 de Junio-></a>
                    <a href="event.html"><button class="tarjet-event-button">Leer mas</button></a>
                </div>
            </div>
            <div class="tarjet-event" id="3">
                <div class="tarjet-event-name">Hackathon ETH</div>
                <div class="tarjet-event-info">2do Lugar en el Hackathon ETH </div>
                <img class="tarjet-event-image" src="images/ejm1.jpg">
                <div class="tarjet-event-buttons">
                    <a class="tarjet-event-link">15 de Junio-></a>
                    <a><button class="tarjet-event-button">Ver mas</button></a>
                </div>
            </div>
            <div class="tarjet-event" id="3">
                <div class="tarjet-event-name">Hackathon ETH</div>
                <div class="tarjet-event-info">2do Lugar en el Hackathon ETH </div>
                <img class="tarjet-event-image" src="images/ejm1.jpg">
                <div class="tarjet-event-buttons">
                    <a class="tarjet-event-link">15 de Junio-></a>
                    <a><button class="tarjet-event-button">Ver mas</button></a>
                </div>
            </div>
            <div class="tarjet-event" id="3">
                <div class="tarjet-event-name">Hackathon ETH</div>
                <div class="tarjet-event-info">2do Lugar en el Hackathon ETH </div>
                <img class="tarjet-event-image" src="images/ejm1.jpg">
                <div class="tarjet-event-buttons">
                    <a class="tarjet-event-link">15 de Junio-></a>
                    <a><button class="tarjet-event-button">Ver mas</button></a>
                </div>
            </div>
            <div class="tarjet-event" id="2">
                <div class="tarjet-event-name">Hackathon ETH</div>
                <div class="tarjet-event-info">2do Lugar en el Hackathon ETH </div>
                <img class="tarjet-event-image" src="images/ejm1.jpg">
                <div class="tarjet-event-buttons">
                    <a><button class="tarjet-event-link">5 de Mayo -></button></a>
                    <a><button class="tarjet-event-button">Leer mas</button></a>
                </div>
            </div>
            <div class="tarjet-event" id="3">
                <div class="tarjet-event-name">Hackathon ETH</div>
                <div class="tarjet-event-info">2do Lugar en el Hackathon ETH </div>
                <img class="tarjet-event-image" src="images/ejm1.jpg">
                <div class="tarjet-event-buttons">
                    <a class="tarjet-event-link">15 de Junio-></a>
                    <a><button class="tarjet-event-button">Ver mas</button></a>
                </div>
            </div>
            <div class="tarjet-event" id="3">
                <div class="tarjet-event-name">Hackathon ETH</div>
                <div class="tarjet-event-info">2do Lugar en el Hackathon ETH </div>
                <img class="tarjet-event-image" src="images/ejm1.jpg">
                <div class="tarjet-event-buttons">
                    <a class="tarjet-event-link">15 de Junio-></a>
                    <a><button class="tarjet-event-button">Ver mas</button></a>
                </div>
            </div>
            <div class="tarjet-event" id="3">
                <div class="tarjet-event-name">Hackathon ETH</div>
                <div class="tarjet-event-info">2do2do Lugar en el Hackathon ETH </div>
                <img class="tarjet-event-image" src="images/ejm1.jpg">
                <div class="tarjet-event-buttons">
                    <a class="tarjet-event-link">15 de Junio-></a>
                    <a><button class="tarjet-event-button">Ver mas</button></a>
                </div>
            </div>
        </section>
        <div class="tarjet-event-more">
            <button class="tarjet-event-button" id="verMasBtn">Ver más</button>
            <button class="tarjet-event-button" id="verMenosBtn">Ver menos</button>
        </div>
        <script src="js/bucle.js"></script>
        <section class="coordinator-container" id="cordinador">
            <div class="coordinator-image">
                <img src="images/ejm2.jpg" id="img4"alt="Foto del coordinador">
            </div>
            <div class="coordinator-info">
                <h2 class="coordinator-title">Nombre del Coordinador</h2>
                <p class="coordinator-p">Información sobre el coordinador Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla gravida lorem at libero tincidunt consequat. Fusce rutrum sit amet justo eget hendrerit.</p>
                <p class="coordinator-contac">Contacto: <a href="mailto:correo@coordinador.com">correo@coordinador.com</a></p>
            </div>
        </section>  
    </main>
    <footer class="footer-content">
        <div class="footer-mails">
            <div class="footer-mails-mail-title">Contactos</div>
            <div class="footer-mails-mail">dradminitacion@fcc.com</div>
            <div class="footer-mails-mail">vinculacion@fcc.com</div>
            <div class="footer-mails-mail">bolsatrabajofcc@gmail.com</div>
        </div>
        <div class="footer-info">
            <div class="footer-info-title-tile">Bolsa de trabajo</div>
            <div class="footer-info-title">Facultad de Computacion</div>
            <div class="footer-info-title">Benemerita Universidad Auntonoma de Puebla</div>
            <div class="footer-info-title">Vinculacion Facultad de Computacion</div>
        </div>
        <div>
            <a href="view/login.html" class="footer-botton"><button>Iniciar Sesion</button></a>
        </div>
    </footer>
</body>
</html><?php /**PATH C:\xampp\htdocs\bolsa-app\resources\views/home/index.blade.php ENDPATH**/ ?>