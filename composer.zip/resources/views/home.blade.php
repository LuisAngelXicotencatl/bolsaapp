@extends('layouts.plantilla')
@section('title', 'home')
@section("content")
    <h1>Bienvenido a laravel</h1>
@endsection