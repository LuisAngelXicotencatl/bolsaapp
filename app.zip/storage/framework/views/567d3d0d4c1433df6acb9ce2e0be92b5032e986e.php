
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection("content"); ?>
    <main class="section-w" id="nosotros">
        <!--Nosotros-->
        <div class="nosotros">
            <div class="nostros-content">
                <div class="nostros-content-title">Bolsa de trabajo FCC</div>
                <div class="nostros-content-text">La Bolsa de Trabajo de la Facultad de Ciencias de la Computación tiene el compromiso de ser un centro de información y consulta que vincule a nuestros alumnos y egresados con las necesidades profesionales de las empresas y organizaciones, brindando una alternativa viable y sustentable que cubra el perfil que solicitan.</div>
            </div>
            <div class="nostros-images">
                <div class="nostros-images-col-a">
                    <img src="<?php echo e(asset('images/empresas/audi.png')); ?>" alt="" class="nostros-images-col-a-image">
                    <img src="<?php echo e(asset('images/empresas/Oracle_Logo.jpg')); ?>" alt="" class="nostros-images-col-a-image">
                </div>
                <div class="nostros-images-col-b">
                    <img src="<?php echo e(asset('images/empresas/tsystemsmexico.png')); ?>" alt="" class="nostros-images-col-b-image">
                    <img src="<?php echo e(asset('images/empresas/buap.png')); ?>" alt="" class="nostros-images-col-b-image">
                </div>
                <div class="nostros-images-col-c">
                    <img src="<?php echo e(asset('images/empresas/vw.png')); ?>" alt="" class="image">
                    <img src="<?php echo e(asset('images/empresas/meta2.png')); ?>" alt="" class="image">
                    <img src="<?php echo e(asset('images/empresas/Oracle_Logo.jpg')); ?>" alt="" class="image">
                </div>
            </div>
        </div>
        <!--EVENTOS-->
        <div class="eventos-title">Eventos pasados</div>
        <section class="eventos" id="eventos">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="tarjet-event" id="2">
                <div class="tarjet-event-name"><?php echo e($event->titulo); ?></div>
                <div class="tarjet-event-info"><?php echo e($event->subtitulo); ?> </div>
                <?php if($event->images->count() > 0): ?>
                    <?php
                        $imagePath = 'storage/' . str_replace('\\', '/', $event->images->first()->image);
                    ?>
                    <img class="tarjet-event-image" src="<?php echo e(asset($imagePath)); ?>">
                <?php endif; ?>
                <div class="tarjet-event-buttons">
                    <a class="tarjet-event-link"><?php echo e($event->fecha); ?>-></a>
                    <a href="<?php echo e(route('Event.indexshow', $event->id)); ?>"><button class="tarjet-event-button">Leer mas</button></a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
        <div class="tarjet-event-more">
            <button class="tarjet-event-button" id="verMasBtn">Ver más</button>
            <button class="tarjet-event-button" id="verMenosBtn">Ver menos</button>
        </div>
        <script src="js/bucle.js"></script>
        <section class="coordinator-container" id="cordinador">
            <div class="coordinator-image">
                <img src="images/ejm2.jpg" id="img4"alt="Foto del coordinador">
            </div>
            <div class="coordinator-info">
                <h2 class="coordinator-title">Nombre del Coordinador</h2>
                <p class="coordinator-p">Información sobre el coordinador Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla gravida lorem at libero tincidunt consequat. Fusce rutrum sit amet justo eget hendrerit.</p>
                <p class="coordinator-contac">Contacto: <a href="mailto:correo@coordinador.com">correo@coordinador.com</a></p>
            </div>
        </section>  
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.inicio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bolsa-app\resources\views/home/index.blade.php ENDPATH**/ ?>