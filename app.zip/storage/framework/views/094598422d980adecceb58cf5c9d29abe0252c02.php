
<?php $__env->startSection('title', 'Empresas'); ?>
<?php $__env->startSection("content"); ?>
<main>
    <div class="eventos-title">Empresas</div>
    <section class="soon">
        <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="soon-event">
            <div class="soon-event-date">
                <div class="soon-event-info-label"><?php echo e($empresa->Nombre); ?></div>
            </div>
            <div class="soon-event-info">
                <div class="soon-event-info-label"><?php echo e($empresa->Descripcion); ?></div>
                <div class="tarjet-event-buttons">
                    <a href="<?php echo e(route('Event.soonUpdate', $empresa->id)); ?>"><button class="tarjet-event-button" id="delete">Ver</button></a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
    <script src="js/bucle.js"></script>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bolsa-app\resources\views/empresas/index.blade.php ENDPATH**/ ?>