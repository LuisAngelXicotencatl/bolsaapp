
<?php $__env->startSection('title', 'Cursos'); ?>
<?php $__env->startSection("content"); ?>
    <h1>Bienvenido a la pagina principal</h1>
    <a href="<?php echo e(route('cursps.create')); ?>">crear curso</a>
    <ul>
        <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(route('cursps.show', $curso->id)); ?>"><?php echo e($curso->name); ?> , <?php echo e($curso->avatar); ?></a>-->
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php echo e($cursos->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bolsa-app\resources\views/cursos/index.blade.php ENDPATH**/ ?>