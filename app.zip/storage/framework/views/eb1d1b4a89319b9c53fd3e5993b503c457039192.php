
<?php $__env->startSection('title', 'home'); ?>
<?php $__env->startSection("content"); ?>
    <h1>Bienvenido a laravel</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bolsa-app\resources\views/home.blade.php ENDPATH**/ ?>